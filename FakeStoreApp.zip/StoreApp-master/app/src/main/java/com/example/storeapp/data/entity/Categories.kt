package com.example.storeapp.data.entity

 class Categories:ArrayList<String>()