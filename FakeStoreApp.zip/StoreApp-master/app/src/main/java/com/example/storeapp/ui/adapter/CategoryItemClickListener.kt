package com.example.storeapp.ui.adapter


interface CategoryItemClickListener {
    fun onItemClick(category: String)
}